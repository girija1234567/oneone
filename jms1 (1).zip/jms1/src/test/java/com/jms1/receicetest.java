package com.jms1;

import static org.junit.Assert.*;

import org.junit.Test;

public class receicetest {
	@Test
public void display()
{
		Receiver r=new Receiver();
		assertEquals("happy",r.receiveMessage());
	
}
	
}
