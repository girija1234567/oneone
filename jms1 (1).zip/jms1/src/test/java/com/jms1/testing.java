package com.jms1;

import static org.junit.Assert.*;

import org.junit.Test;

public class testing {
@Test
	public void dis()
	{
		Sender s=new Sender();
		assertEquals("happy",s.sendMessage("happy"));
	}
}
