package defaultnamespace.jaxws;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;


import defaultnamespace.*;

/**
 * Root resource (exposed at "myresource" path)
 */
@WebService
public class MyResource {
	
	

    @WebMethod
   public List<Employee> getEmployees()
    {
	  EmployeeDetails a=new EmployeeDetails();
	  return a.getAllEmployee();
    }
    
}


