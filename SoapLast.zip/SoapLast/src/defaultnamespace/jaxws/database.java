package defaultnamespace.jaxws;

import java.util.HashMap;
import java.util.Map;

import defaultnamespace.*;

public class database {

	private static Map<Integer,Employee> employees=new HashMap();
	public static Map<Integer,Employee> getEmployees()
	{
		return employees;
	}
	
}
