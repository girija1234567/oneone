package defaultnamespace.jaxws;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import defaultnamespace.*;

public class EmployeeDetails {
	
	private static  Map<Integer,Employee> a=database.getEmployees();
	
	
	
	public EmployeeDetails()
	{
		a.put(1,new Employee("m1042933","girija"));
		a.put(2,new Employee("m1897665","chandana"));
	}
	
	public static  List<Employee> getAllEmployee()
	{
		return new ArrayList<Employee>(a.values());
	}
	
	public Employee getEmployee(int id)
	{
		return a.get(id);
	}
	
	

}
