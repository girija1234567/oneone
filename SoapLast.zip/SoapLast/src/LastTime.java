import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService(targetNamespace = "http://default_package/", portName = "LastTimePort", serviceName = "LastTimeService")
public class LastTime {
  
	@WebMethod(operationName = "addition", action = "urn:Addition")
	public int addition(int a,int b)
	{
		return a+b;
	}
}
