package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.Student;

public class studentimple implements studentinter{

	@Override
	public String Insert(Student s) {
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		try
		{
			Session session=sf.openSession();
			Transaction tx=session.beginTransaction();
			session.save(s);
			tx.commit();
			session.close();
			sf.close();
			return "true";
		}
		catch(HibernateException e)
		{
			e.printStackTrace();
		}
		return "false";
	}

	@Override
	public String Update(Student s) {
		 Transaction trns = null;
	        Session session = new Configuration().configure().buildSessionFactory().openSession();
	        try {
	            trns = session.beginTransaction();
	            session.update(s);
	            session.getTransaction().commit();
	            return "true";
	        } catch (HibernateException e) {
	            e.printStackTrace();
	        } 
	        return "false";
	}

	@Override
	public Student RetrieveDetails(int id) {
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
        try 
        {
        	Session session=sf.openSession();
        	Student st=(Student)session.get(Student.class,id);
        	System.out.println("user name read from db is = "+st.getEmp_name());
        	return st;
        }
        catch(HibernateException e)
        {
        	e.printStackTrace();
        }
        return null;
	}

	@Override
	public String Delete(int eid) {
		 Transaction trns = null;
	        Session session = new Configuration().configure().buildSessionFactory().openSession();
	        try {
	            trns = session.beginTransaction();
	            Student st = (Student) session.load(Student.class, new Integer(eid));
	            session.delete(st);
	            session.getTransaction().commit();
	            return "true";
	        } 
	        catch (RuntimeException e)
	        {
	        	e.printStackTrace();
	        } 
	        return "false";
	}
	
	public List<Student> getAll() {
        List<Student> s1 = new ArrayList<Student>();
        Transaction trns = null;
        Session session = new Configuration().configure().buildSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            s1= session.createQuery("from Student").list();
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
        return s1;
    }

	

}
