package com.dao;

import java.util.List;

import com.pojo.Student;

public interface studentinter {
	
	public String Insert(Student s);
	public String Update(Student s);
	public Student RetrieveDetails(int id);
	public String Delete(int eid);
	public List<Student> getAll();

}
