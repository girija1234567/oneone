package com.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import com.pojo.Student;
import com.restfulexm.MyResource;

public class studenttest {
	@Test
	public void InsertTest()
	{
	studentimple it=new studentimple();
		Student s=new Student();
		
		assertEquals("true", it.Insert(s));
	}

	//@Test
	public void RetrieveTest()
	{

	MyResource m=new MyResource();
		List<Student>l=m.getDetails();
		assertEquals(l,m.getDetails());
	}

}
