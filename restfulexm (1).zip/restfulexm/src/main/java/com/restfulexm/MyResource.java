package com.restfulexm;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.dao.studentimple;
import com.dao.studentinter;
import com.pojo.Student;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {
	studentinter i1=new studentimple();

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
  /*  public String getIt() {
        return "Got it!";
    }   */
    public List<Student> getDetails()
    {
    	return i1.getAll();
    }
    
    @POST
    @Produces(MediaType.APPLICATION_XML)
    @Consumes(MediaType.APPLICATION_XML)
    public String entering(Student s)
    {
    	return i1.Insert(s);
    }
    @GET
    @Path("/{employeeid}")
    @Produces(MediaType.APPLICATION_XML)
    public Student getById( @PathParam("employeeid") int id)
    {
    	return i1.RetrieveDetails(id);
    }
    
    
}
