package com.inter;
import java.util.Arrays;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.pojo.campusmind;

public class Implementation implements interfaceexm 
{

	public campusmind getDetailsById(int Mid) { 
		Transaction trns = null;
	    Session session = new Configuration().configure().buildSessionFactory().openSession();
	    campusmind res=null;
	        try {
	        	trns=session.beginTransaction();
	        	Query query=session.createQuery("from campusmind where mid=:mid");
	        	query.setInteger("mid",Mid);
	        	res=(campusmind) query.uniqueResult();
	        	session.getTransaction().commit();
	        	}
	        catch(RuntimeException e)
	        {
	        if(trns!=null)
	        {
	        	trns.rollback();
	        }
	        e.printStackTrace();
	        }
	        finally
	        {
	        	session.close();
	        }
	        return res;
	    } 
	
	

	public void getDetailsByName(int Lid)
	{
	Transaction trns=null;
	List<Object[]>list=null;
	Session session = new Configuration().configure().buildSessionFactory().openSession();
	trns=session.beginTransaction();
	Query query=session.createQuery("from campusmind,lead where Lead_FK=L_Id  and Lid=:lid");
	query.setInteger("lid", Lid);
	list=query.list();
		for(Object[]arr:list)
		{
			System.out.println(Arrays.toString(arr));
		}
		session.getTransaction();
		session.close();
	}

	
}
