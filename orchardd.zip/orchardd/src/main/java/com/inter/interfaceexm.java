package com.inter;

import com.pojo.campusmind;

public interface interfaceexm {
	public campusmind getDetailsById(int mid);
	public void getDetailsByName(int lid);
}
