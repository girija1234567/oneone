package com.pojo;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="lead")
public class lead {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	@Column(name="L_Id")
	private int id;
	private int lid;
	private String lname;
	@OneToMany(mappedBy="lead1")
	@ElementCollection
	private Collection<campusmind> cminds=new ArrayList<campusmind>();
	
	
	public Collection<campusmind> getCminds() {
		return cminds;
	}
	public void setCminds(Collection<campusmind> cminds) {
		this.cminds = cminds;
	}
	public lead()
	{
		
	}
	public lead(int id, int lid, String lname) {
		super();
		this.lid = lid;
		this.lname = lname;
	}
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public int getLid() {
		return lid;
	}
	public void setLid(int lid) {
		this.lid = lid;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	@Override
	public String toString() {
		return "lead [id=" + id + ", lid=" + lid + ", lname=" + lname + "]";
	}
	
	



}
