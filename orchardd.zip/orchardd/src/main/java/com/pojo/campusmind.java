package com.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;
@Entity
@Table(name="campus")
public class campusmind
{
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
private int mid;
private String name;
private String email;
public campusmind()
{

}
public campusmind(int mid, String name, String email, MindDetails minds, lead lead1) {
	super();
	this.mid = mid;
	this.name = name;
	this.email = email;
	this.minds = minds;
	this.lead1 = lead1;
}
@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
@JoinColumn(name="reference")
private MindDetails minds;
public void setMinds(MindDetails minds) {
	this.minds = minds;
}
public MindDetails getMinds() {
	return minds;
}
@ManyToOne
@JoinColumn(name="lead_FK")
private lead lead1;
public lead getLead1() {
	return lead1;
}
public void setLead1(lead lead1) {
	this.lead1 = lead1;
}
public int getMid() {
	return mid;
}

public void setMid(int mid) {
	this.mid = mid;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}


@Override
public String toString() {
	return "campusmind [mid=" + mid + ", name=" + name + ", email=" + email + ", minds=" + minds.getHometown()+ minds.getPincode()+","
			+ " lead1="+ lead1.getLid()+ lead1.getLname() + "]";
}




}
