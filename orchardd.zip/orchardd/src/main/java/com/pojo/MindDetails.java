package com.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="minddetails")
public class MindDetails {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private int id;
	private String hometown;
	public MindDetails()
	{
		
	}
	public MindDetails( String hometown, int pincode) {
		super();
	
		this.hometown = hometown;
		this.pincode = pincode;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private int pincode;
	public String getHometown() {
		return hometown;
	}
	public void setHometown(String hometown) {
		this.hometown = hometown;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "MindDetails [id=" + id + ", hometown=" + hometown + ", pincode=" + pincode + "]";
	}
	
	
	
}
