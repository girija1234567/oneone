package com.orchardd;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.inter.Implementation;
import com.inter.interfaceexm;
import com.pojo.MindDetails;
import com.pojo.campusmind;
import com.pojo.lead;
public class App 
{
    public static void main( String[] args )
    {
     SessionFactory sf = new Configuration().configure().buildSessionFactory();
     Transaction trns=null;
     Session session=sf.openSession();
	
    /* try
     {
    	 trns=session.beginTransaction();
      lead l1=new lead();
     
      l1.setLid(10);
      l1.setLname("ntr");
      MindDetails m=new MindDetails("tirupathi",517235);
      MindDetails m1=new MindDetails("chittor",516453);
      campusmind c1=new campusmind(200,"girija","girija.b@mail.com",m,l1);
      campusmind c2=new campusmind(210,"geetha","geetha.b@mail.com",m1,l1);
      l1.getCminds().add(c1);
      l1.getCminds().add(c2);
      session.save(l1);
      session.save(c1);
      session.save(c2);
      trns.commit();
      }
     catch(HibernateException e)
     {
    	 e.printStackTrace();
     }  */
     Scanner s=new Scanner(System.in);
      try
      {
    	  System.out.println("enter the campusmind mid");
    	  int mid=s.nextInt();
    	  interfaceexm i=new Implementation();
    	  campusmind res=i.getDetailsById(mid);
    	  System.out.println(res);
    	  System.out.println("enter thr lead lid");
    	  int lid=s.nextInt();
    	  i.getDetailsByName(lid);
     }
      catch(RuntimeException e)
      {
    	  e.printStackTrace();
      }
    }
}
